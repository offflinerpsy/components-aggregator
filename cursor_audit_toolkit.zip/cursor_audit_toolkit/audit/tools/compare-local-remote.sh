#!/usr/bin/env bash
set -euo pipefail
HOST="${HOST:-}"
USER="${USER:-}"
REMOTE_PATH="${REMOTE_PATH:-}"
[[ -n "$HOST" && -n "$USER" && -n "$REMOTE_PATH" ]] || { echo "Set HOST, USER, REMOTE_PATH env vars"; exit 1; }

LOGDIR="audit/logs"
mkdir -p "$LOGDIR"
OUT="$LOGDIR/diff-$(date +%Y%m%d-%H%M%S).txt"

EXCLUDES=(
  "--exclude=.git" "--exclude=node_modules" "--exclude=vendor"
  "--exclude=dist" "--exclude=build" "--exclude=.next"
  "--exclude=coverage" "--exclude=uploads" "--exclude=storage"
  "--exclude=.cache" "--exclude=tmp" "--exclude=.terraform"
)

rsync -azvn --delete "${EXCLUDES[@]}" ./ "${USER}@${HOST}:${REMOTE_PATH}/" | tee "$OUT"
echo "[OK] Dry-run diff saved to $OUT"
