#!/usr/bin/env bash
set -euo pipefail
OUT="audit/logs/inventory-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$OUT"
if command -v tree >/dev/null 2>&1; then
  tree -a -I '.git|node_modules|vendor|dist|build|.next|coverage|uploads|storage|.cache|tmp|.terraform' > "$OUT/TREE.txt"
else
  find . -maxdepth 6 -type f -not -path '*/.git/*' -not -path '*/node_modules/*' | sort > "$OUT/TREE.txt"
fi
for f in package.json pnpm-lock.yaml yarn.lock package-lock.json composer.json composer.lock requirements.txt pyproject.toml poetry.lock go.mod go.sum; do
  if [[ -f "$f" ]]; then cp -a "$f" "$OUT/"; fi
done
{ git rev-parse --abbrev-ref HEAD > "$OUT/GIT_BRANCH.txt"; } 2>/dev/null || true
{ git rev-parse HEAD > "$OUT/GIT_HEAD.txt"; } 2>/dev/null || true
{ git status --porcelain=v1 > "$OUT/GIT_STATUS.txt"; } 2>/dev/null || true
{ git log --oneline -n 30 > "$OUT/GIT_LOG.txt"; } 2>/dev/null || true
echo "[OK] Inventory saved to $OUT"
