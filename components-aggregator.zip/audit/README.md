# Project Audit & Test Bot — Brief (for Cursor)

## Задача (человеческим языком)
1) Прекратить хаос с «разными папками». Установить **одну точку правды** и проверить, что локальные файлы совпадают с сервером.
2) Пройтись ботом по сайту **в двух режимах**: без рендера (быстро) и с полным рендером браузером — и залогировать:
   - есть ли все характеристики, PDF, изображения;
   - нет ли ошибок на страницах;
   - где расхождения с «донором» (референсной страницей).
3) Включить бота **в фоне по расписанию**, чтобы ловить регрессии автоматически.
4) **Починить логирование**: писать JSONL-логи по одной записи на URL, чтобы потом глазами и скриптами быстро искать ошибки.

## Что внутри
- `audit/tools/inventory.sh` — инвентаризация локального проекта (дерево, манифесты, git-мета).
- `audit/tools/compare-local-remote.sh` — безопасное сравнение локаль ↔ сервер (rsync dry-run, ничего не трогает).
- `audit/bot/runner.js` — бот-проверяльщик (HTTP/Rendered), пишет логи в JSONL.
- `audit/bot/schema.json` — минимальная схема ожидаемых полей карточки.
- `audit/bot/config.example.json` — пример конфига.
- `audit/systemd/deep-audit-bot.service|.timer` — запуск бота по расписанию.
- `audit/README.md` — эта инструкция.

## Быстрый старт
```bash
# 0) Настрой конфиг
cp audit/bot/config.example.json audit/bot/config.json
$EDITOR audit/bot/config.json

# 1) Инвентаризация локально
bash audit/tools/inventory.sh

# 2) Сравнить с сервером (dry-run; задайте HOST/USER/REMOTE_PATH)
HOST=example.com USER=root REMOTE_PATH=/var/www/site bash audit/tools/compare-local-remote.sh

# 3) Прогон бота
node audit/bot/runner.js --mode=http   --out=audit/logs/run-http-$(date +%Y%m%d-%H%M%S)   --limit=200
node audit/bot/runner.js --mode=render --out=audit/logs/run-render-$(date +%Y%m%d-%H%M%S) --limit=100

# 4) В фоне по таймеру (на сервере)
sudo cp audit/systemd/* /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now deep-audit-bot.timer
```

## Замечания
- Бот использует Node 20+, `undici` (HTTP) и `puppeteer` (рендер). Устанавливаются при первом запуске командой `npm i undici puppeteer` в корне проекта (или глобально).
- **Логи**: `audit/logs/*.jsonl` — одна строка = один URL (удобно grep/jq).
- **Донор**: настроить карту соответствий в `config.json` (`DONOR_MAP`), если нужен посрочный дифф блоков.
