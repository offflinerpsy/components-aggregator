# micro chip preloader

A Pen created on CodePen.

Original URL: [https://codepen.io/bhavyam-agarwal/pen/zxYoPqo](https://codepen.io/bhavyam-agarwal/pen/zxYoPqo).

