# Text Animation with background

A Pen created on CodePen.

Original URL: [https://codepen.io/yemon/pen/YrPmQr](https://codepen.io/yemon/pen/YrPmQr).

