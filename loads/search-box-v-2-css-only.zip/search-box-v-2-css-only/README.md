# Search box v.2 (CSS Only)

A Pen created on CodePen.

Original URL: [https://codepen.io/takaneichinose/pen/ErGwPZ](https://codepen.io/takaneichinose/pen/ErGwPZ).

After learning the cubic bezier function on CSS transition, I tried remaking the [search box that I did before](https://codepen.io/takaneichinose/pen/gKVXXL).